# A tap-to-earn project as a telegram mini-app using React

# Live demo:

https://trocoin.netlify.app/
